# PT-WGAN
Code for paper "Parameter-Transferred Wasserstein Generative Adversarial Network (PT-WGAN) for Low-Dose PET Image Denoising".
If any question, please connect me via email.
E-mail: yu.90n9@gmail.com
